namespace UM.CustomFx.GratefulPatient.UIModel
{

	public partial class UMHSInteractionViewDataFormUIModel
	{

		private void UMHSInteractionViewDataFormUIModel_Loaded(object sender, Blackbaud.AppFx.UIModeling.Core.LoadedEventArgs e)
		{

		}

#region "Event handlers"

		partial void OnCreated()
		{
			this.Loaded += UMHSInteractionViewDataFormUIModel_Loaded;
		}

#endregion

	}

}